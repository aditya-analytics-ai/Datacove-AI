/**
 * ErrorBoundary — catches React render errors that would otherwise
 * cause a blank white page with no recovery path.
 */
import React from "react";

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error("[ErrorBoundary]", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          display: "flex", flexDirection: "column", alignItems: "center",
          justifyContent: "center", height: "100%", gap: 16,
          background: "var(--bg, #0f0f14)", color: "var(--text-0, #e4e4f0)",
          fontFamily: "Inter, sans-serif", padding: 32,
        }}>
          <div style={{ fontSize: 32 }}>⚠️</div>
          <div style={{ fontSize: 18, fontWeight: 700 }}>Something went wrong</div>
          <div style={{
            fontSize: 12, color: "var(--text-2, #888)",
            maxWidth: 480, textAlign: "center", lineHeight: 1.6,
            background: "rgba(255,255,255,0.04)", padding: "12px 20px",
            borderRadius: 8, fontFamily: "monospace",
          }}>
            {this.state.error?.message ?? "An unexpected render error occurred."}
          </div>
          <button
            onClick={() => this.setState({ hasError: false, error: null })}
            style={{
              padding: "10px 24px", borderRadius: 8, border: "none",
              background: "linear-gradient(135deg,#6366f1,#a855f7)",
              color: "#fff", fontSize: 13, fontWeight: 600,
              cursor: "pointer", marginTop: 8,
            }}
          >
            Try to recover
          </button>
          <button
            onClick={() => window.location.reload()}
            style={{
              padding: "8px 20px", borderRadius: 8,
              border: "1px solid rgba(255,255,255,0.12)",
              background: "transparent", color: "var(--text-1, #aaa)",
              fontSize: 12, cursor: "pointer",
            }}
          >
            Reload page
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
