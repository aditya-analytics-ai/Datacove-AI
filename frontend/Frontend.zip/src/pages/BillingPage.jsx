/**
 * BillingPage — Plan overview, usage stats, and upgrade flow.
 * Fetches current tier + usage from /api/billing/me and plan catalogue
 * from /api/billing/plans. Upgrade redirects to Stripe Checkout.
 */
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft, Zap, Users, Shield, CheckCircle2,
  AlertCircle, Loader2, BarChart2, Database, Bot,
} from "lucide-react";
import { fetchBillingMe, fetchPlans, createCheckout } from "../services/api";

const TIER_COLORS = { free: "#737a9e", pro: "#6366f1", team: "#0891b2" };
const TIER_ICONS  = { free: Shield, pro: Zap, team: Users };

function UsageBar({ label, used, limit, icon: Icon }) {
  const pct = limit ? Math.min(100, Math.round((used / limit) * 100)) : 0;
  const color = pct > 85 ? "#ef4444" : pct > 60 ? "#f59e0b" : "#22c55e";
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between",
        alignItems: "center", marginBottom: 5 }}>
        <span style={{ display: "flex", alignItems: "center", gap: 5,
          fontSize: 12, color: "var(--text-1)", fontWeight: 500 }}>
          {Icon && <Icon size={11} />} {label}
        </span>
        <span style={{ fontSize: 11, color: "var(--text-2)" }}>
          {used.toLocaleString()} {limit ? `/ ${limit.toLocaleString()}` : "/ ∞"}
        </span>
      </div>
      {limit && (
        <div style={{ height: 4, background: "var(--surface-3)",
          borderRadius: 99, overflow: "hidden" }}>
          <div style={{ width: `${pct}%`, height: "100%",
            background: color, borderRadius: 99,
            transition: "width .4s ease" }} />
        </div>
      )}
    </div>
  );
}

export default function BillingPage() {
  const navigate = useNavigate();
  const [me, setMe]         = useState(null);
  const [plans, setPlans]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [upgrading, setUpgrading] = useState(null);
  const [error, setError]   = useState("");

  useEffect(() => {
    Promise.all([fetchBillingMe(), fetchPlans()])
      .then(([meRes, plansRes]) => {
        setMe(meRes);
        setPlans(plansRes.plans || []);
      })
      .catch(() => setError("Could not load billing information."))
      .finally(() => setLoading(false));
  }, []);

  const handleUpgrade = async (planId) => {
    setUpgrading(planId);
    try {
      const res = await createCheckout(
        planId,
        `${window.location.origin}/billing?success=1`,
        `${window.location.origin}/billing?cancelled=1`,
      );
      if (res.checkout_url) window.location.href = res.checkout_url;
    } catch {
      setError("Could not start checkout. Please try again.");
    } finally {
      setUpgrading(null);
    }
  };

  const css = `
    .bl-page { min-height: 100vh; background: var(--bg); padding: 32px; }
    .bl-back { display: inline-flex; align-items: center; gap: 6px; font-size: 12px;
      color: var(--text-2); cursor: pointer; border: none; background: none;
      margin-bottom: 24px; padding: 0; }
    .bl-back:hover { color: var(--text-0); }
    .bl-header { margin-bottom: 32px; }
    .bl-title { font-size: 20px; font-weight: 700; color: var(--text-0); }
    .bl-sub { font-size: 13px; color: var(--text-2); margin-top: 4px; }
    .bl-grid { display: grid; grid-template-columns: 1fr 2fr; gap: 20px;
      max-width: 900px; }
    @media (max-width: 640px) { .bl-grid { grid-template-columns: 1fr; } }
    .bl-card { background: var(--surface-1); border: 1px solid var(--border);
      border-radius: var(--radius-lg); padding: 20px; }
    .bl-section-title { font-size: 11px; font-weight: 600; color: var(--text-2);
      text-transform: uppercase; letter-spacing: .07em; margin-bottom: 14px; }
    .bl-tier-badge { display: inline-flex; align-items: center; gap: 6px;
      font-size: 14px; font-weight: 700; padding: 6px 14px;
      border-radius: 99px; margin-bottom: 16px; }
    .bl-plan-list { display: grid; gap: 10px; }
    .bl-plan { background: var(--surface-2); border: 1px solid var(--border);
      border-radius: var(--radius-md); padding: 16px;
      display: flex; align-items: flex-start; gap: 12px; }
    .bl-plan--current { border-color: var(--accent); background: var(--accent-dim); }
    .bl-plan-icon { width: 36px; height: 36px; border-radius: var(--radius-sm);
      display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .bl-plan-info { flex: 1; }
    .bl-plan-name { font-size: 13px; font-weight: 600; color: var(--text-0); }
    .bl-plan-price { font-size: 12px; color: var(--text-2); margin-top: 2px; }
    .bl-plan-feats { margin-top: 8px; display: flex; flex-direction: column; gap: 4px; }
    .bl-feat { display: flex; align-items: center; gap: 5px;
      font-size: 11px; color: var(--text-1); }
    .bl-upgrade-btn { margin-top: 12px; display: inline-flex; align-items: center;
      gap: 6px; padding: 7px 16px; background: var(--accent); color: #fff;
      border: none; border-radius: var(--radius-sm); font-size: 12px;
      font-weight: 500; cursor: pointer; }
    .bl-upgrade-btn:hover { opacity: .9; }
    .bl-upgrade-btn:disabled { opacity: .4; cursor: default; }
    .bl-current-tag { font-size: 10px; font-weight: 600; padding: 2px 8px;
      background: var(--accent); color: #fff; border-radius: 99px; }
    .bl-err { display: flex; align-items: center; gap: 6px; font-size: 12px;
      color: var(--red); margin-bottom: 16px; }
  `;

  if (loading) return (
    <div style={{ display: "flex", justifyContent: "center",
      alignItems: "center", height: "60vh" }}>
      <Loader2 size={24} style={{ animation: "spin .7s linear infinite",
        color: "var(--text-3)" }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );

  const currentTier = me?.tier || "free";
  const usage = me?.usage || {};
  const limits = me?.limits || {};
  const tierColor = TIER_COLORS[currentTier] || "#737a9e";

  return (
    <>
      <style>{css}</style>
      <div className="bl-page">
        <button className="bl-back" onClick={() => navigate(-1)}>
          <ArrowLeft size={13} /> Back
        </button>
        <div className="bl-header">
          <div className="bl-title">Billing & Plan</div>
          <div className="bl-sub">Manage your subscription and track usage</div>
        </div>

        {error && <div className="bl-err"><AlertCircle size={12} /> {error}</div>}

        <div className="bl-grid">
          {/* Current usage */}
          <div className="bl-card">
            <div className="bl-section-title">Current usage</div>
            <div className="bl-tier-badge" style={{
              background: `${tierColor}1a`,
              color: tierColor,
              border: `1px solid ${tierColor}40`,
            }}>
              {React.createElement(TIER_ICONS[currentTier] || Shield, { size: 14 })}
              {currentTier.charAt(0).toUpperCase() + currentTier.slice(1)} plan
            </div>
            <UsageBar
              label="Datasets"
              used={usage.datasets || 0}
              limit={limits.max_datasets}
              icon={Database}
            />
            <UsageBar
              label="Rows per upload"
              used={usage.max_rows_used || 0}
              limit={limits.max_rows}
              icon={BarChart2}
            />
            <UsageBar
              label="AI calls today"
              used={usage.ai_calls_today || 0}
              limit={limits.ai_calls_per_day}
              icon={Bot}
            />
          </div>

          {/* Plan comparison */}
          <div className="bl-card">
            <div className="bl-section-title">Available plans</div>
            <div className="bl-plan-list">
              {plans.map(plan => {
                const PlanIcon = TIER_ICONS[plan.id] || Shield;
                const color = TIER_COLORS[plan.id] || "#737a9e";
                const isCurrent = plan.id === currentTier;
                return (
                  <div key={plan.id}
                    className={`bl-plan${isCurrent ? " bl-plan--current" : ""}`}>
                    <div className="bl-plan-icon"
                      style={{ background: `${color}1a` }}>
                      <PlanIcon size={16} color={color} />
                    </div>
                    <div className="bl-plan-info">
                      <div style={{ display: "flex", alignItems: "center",
                        gap: 8, marginBottom: 2 }}>
                        <span className="bl-plan-name">{plan.name}</span>
                        {isCurrent && <span className="bl-current-tag">Current</span>}
                      </div>
                      <div className="bl-plan-price">
                        {plan.price_monthly === 0
                          ? "Free"
                          : `$${plan.price_monthly}/mo`}
                      </div>
                      <div className="bl-plan-feats">
                        {(plan.features || []).slice(0, 4).map(f => (
                          <span key={f} className="bl-feat">
                            <CheckCircle2 size={10} color="#22c55e" /> {f}
                          </span>
                        ))}
                      </div>
                      {!isCurrent && plan.id !== "free" && (
                        <button
                          className="bl-upgrade-btn"
                          onClick={() => handleUpgrade(plan.id)}
                          disabled={!!upgrading}
                        >
                          {upgrading === plan.id
                            ? <Loader2 size={12} style={{ animation: "spin .7s linear infinite" }} />
                            : <Zap size={12} />}
                          Upgrade to {plan.name}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </>
  );
}
