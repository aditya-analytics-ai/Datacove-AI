/**
 * App.jsx — v5 with improved global theme tokens and font loading.
 */
import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import UploadPage from "./pages/UploadPage";
import Dashboard  from "./pages/Dashboard";
import AuthModal     from "./components/AuthModal";
import DatasetsPage  from "./pages/DatasetsPage";
import BillingPage   from "./pages/BillingPage";
import AdminPage    from "./pages/AdminPage";
import { authMe, setAuthToken } from "./services/api";

const GLOBAL_CSS = `
  *, *::before, *::after { box-sizing: border-box; }

  :root {
    --bg:        #06080c;
    --surface-1: #0d1017;
    --surface-2: #141824;
    --surface-3: #1a2030;
    --surface-glass: rgba(20, 24, 36, 0.45);
    
    --border:    #222a3f;
    --border-2:  #2d3752;
    --border-glass: rgba(255, 255, 255, 0.06);

    --text-0: #f8fafc;
    --text-1: #cbd5e1;
    --text-2: #808b9f;
    --text-3: #475569;

    --accent:       #6366f1;
    --accent-light: #818cf8;
    --accent-hover: #4f46e5;
    --accent-dim:   rgba(99,102,241,0.12);
    
    --gradient-primary: linear-gradient(135deg, #6366f1 0%, #c026d3 100%);
    --gradient-primary-hover: linear-gradient(135deg, #4f46e5 0%, #d946ef 100%);
    --gradient-surface: linear-gradient(180deg, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0) 100%);
    
    --green:  #22c55e;
    --amber:  #f59e0b;
    --red:    #ef4444;

    --radius-sm: 6px;
    --radius-md: 10px;
    --radius-lg: 16px;
    --radius-xl: 24px;
    
    --shadow-sm: 0 4px 12px rgba(0,0,0,0.2), inset 0 1px 1px rgba(255,255,255,0.05);
    --shadow-md: 0 8px 24px rgba(0,0,0,0.3), inset 0 1px 1px rgba(255,255,255,0.05);
    --shadow-lg: 0 16px 40px rgba(0,0,0,0.4), inset 0 1px 1px rgba(255,255,255,0.06);
  }

  html, body, #root { height: 100%; margin: 0; padding: 0; }

  body {
    font-family: 'Outfit', 'Inter', system-ui, sans-serif;
    background: var(--bg);
    color: var(--text-0);
    -webkit-font-smoothing: antialiased;
    font-size: 13.5px;
    letter-spacing: 0.01em;
  }

  ::-webkit-scrollbar        { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track  { background: transparent; }
  ::-webkit-scrollbar-thumb  { background: var(--border); border-radius: 99px; }
  ::-webkit-scrollbar-thumb:hover { background: var(--border-2); }

  :focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; border-radius: 4px; }

  /* Universal transition smoothening */
  button, a {
    cursor: pointer;
  }
  
  /* Buttons using primary gradient */
  .btn-gradient {
    background: var(--gradient-primary);
    border: none;
    color: white;
    box-shadow: 0 2px 10px rgba(99,102,241,0.25), inset 0 1px 1px rgba(255,255,255,0.2);
    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  }
  .btn-gradient:hover:not(:disabled) {
    background: var(--gradient-primary-hover);
    box-shadow: 0 4px 16px rgba(99,102,241,0.35), inset 0 1px 1px rgba(255,255,255,0.25);
    transform: translateY(-1px);
  }
  .btn-gradient:active:not(:disabled) {
    transform: translateY(1px) scale(0.98);
  }
  
  .glass-panel {
    background: var(--surface-glass);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border: 1px solid var(--border-glass);
    box-shadow: var(--shadow-md);
  }
`;

export default function App() {
  const [authReady,   setAuthReady]   = useState(false);
  const [needsAuth,   setNeedsAuth]   = useState(false);
  const [userRole,    setUserRole]    = useState("user");
  const [backendDown, setBackendDown] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("dc_token");
    if (saved) setAuthToken(saved);
    authMe()
      .then(u => {
        setAuthReady(true);
        setNeedsAuth(false);
        setUserRole(u?.role || "user");
      })
      .catch(err => {
        const status = err?.response?.status;
        if (!status) {
          // Network error — backend unreachable
          // Still require auth: clear any stale token and show modal
          localStorage.removeItem("dc_token");
          setAuthToken(null);
          setBackendDown(true);
          setNeedsAuth(true);
        } else {
          // 401 Unauthorized or 403 Forbidden → show login modal
          setNeedsAuth(true);
        }
        setAuthReady(true);
      });
  }, []);

  // Called by AuthModal after successful login/register — update role immediately
  function handleAuthenticated(res) {
    setNeedsAuth(false);
    setBackendDown(false);
    if (res?.role) setUserRole(res.role);
  }

  if (!authReady) return null;

  return (
    <>
      <style>{GLOBAL_CSS}</style>
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" />
      <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        {needsAuth && <AuthModal onAuthenticated={handleAuthenticated} backendDown={backendDown} />}
        <Routes>
          <Route path="/"          element={<UploadPage userRole={userRole} />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/datasets"  element={<DatasetsPage />} />
          <Route path="/billing"   element={<BillingPage />} />
          <Route path="/admin"     element={<AdminPage userRole={userRole} />} />
          <Route path="*"          element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}
